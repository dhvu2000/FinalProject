package com.example.GymLifeServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymLifeServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
